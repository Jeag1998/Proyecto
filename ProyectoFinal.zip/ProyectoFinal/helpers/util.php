<?php
function obtenerRutaImagen($nombreArchivo, $carpeta) {
    $rutaCompleta = $carpeta . $nombreArchivo;

    if (!empty($nombreArchivo) && file_exists($rutaCompleta)) {
        return $rutaCompleta;
    }

    return $carpeta . 'default.png'; // Imagen por defecto
}
