<?php
require_once '../conexion/auth.php';
require_once '../conexion/conexion.php';
require_once '../controlador/publicidadController.php';
require_once '../helpers/util.php';
include 'includes/layout.php';

// Cargar imágenes de publicidad
$publicidadController = new PublicidadController();
$banner1 = $publicidadController->buscarPorDescripcion("inicio1");
$banner2 = $publicidadController->buscarPorDescripcion("inicio2");

$carpetaPublicidad = '../public/img/publi/';
$img1 = isset($banner1[0]['imagen']) ? obtenerRutaImagen($banner1[0]['imagen'], $carpetaPublicidad) : $carpetaPublicidad . 'default.png';
$img2 = isset($banner2[0]['imagen']) ? obtenerRutaImagen($banner2[0]['imagen'], $carpetaPublicidad) : $carpetaPublicidad . 'default.png';
?>

<div class="content text-light">
    <div class="row row-cols-1 row-cols-md-2 g-4 mb-5">
        <div class="col">
            <div class="card bg-dark text-white shadow-sm h-100">
                <img src="<?= $img1 ?>" class="card-img-top" alt="Publicidad 1" style="height: 300px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title">🔥 Publicidad destacada</h5>
                    <p class="card-text"><?= htmlspecialchars($banner1[0]['descripcion'] ?? 'Sin descripción.') ?></p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card bg-secondary text-white shadow-sm h-100">
                <img src="<?= $img2 ?>" class="card-img-top" alt="Publicidad 2" style="height: 300px; object-fit: cover;">
                <div class="card-body">
                    <h5 class="card-title">🎯 Oferta especial</h5>
                    <p class="card-text"><?= htmlspecialchars($banner2[0]['descripcion'] ?? 'Sin descripción.') ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Botones de navegación -->
    <div class="text-center mt-5">
        <a href="videojuegos.php" class="btn btn-outline-light btn-lg m-3 px-5">🎮 Videojuegos</a>
        <a href="coleccion.php" class="btn btn-outline-info btn-lg m-3 px-5">📚 Tu Colección</a>
        <a href="merchand.php" class="btn btn-outline-success btn-lg m-3 px-5">🛍️ Merchand</a>
    </div>
</div>
