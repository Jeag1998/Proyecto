<?php
session_start();
require_once '../conexion/conexion.php';
include 'includes/layout.php';

// Verifica si el usuario está logueado
if (!isset($_SESSION['cod_usuario'])) {
    header("Location: ../index.php");
    exit();
}
?>

<div class="content text-light">
    <div class="row align-items-center mb-5">
        <!-- Imagen grande -->
        <div class="col-md-8">
            <img src="img/dashboard_main.jpg" alt="Dashboard principal" class="img-fluid rounded shadow w-100" style="max-height: 400px; object-fit: cover;">
        </div>

        <!-- Banner lateral tipo publicidad -->
        <div class="col-md-4">
            <div class="bg-secondary rounded shadow p-3 text-center" style="height: 100%; display: flex; flex-direction: column; justify-content: center;">
                <h4 class="mb-3">🎯 ¡Promoción especial!</h4>
                <p>Compra 2 videojuegos y llévate un 20% de descuento en merchand.</p>
                <img src="img/publicidad.jpg" alt="Publicidad" class="img-fluid rounded mt-3">
            </div>
        </div>
    </div>

    <!-- Botones de navegación -->
    <div class="text-center mt-5">
        <a href="listajuegos.php" class="btn btn-outline-light btn-lg m-3 px-5">🎮 Videojuegos</a>
        <a href="tusjuegos.php" class="btn btn-outline-info btn-lg m-3 px-5">📚 Tu Colección</a>
        <a href="merchand.php" class="btn btn-outline-success btn-lg m-3 px-5">🛍️ Merchand</a>
    </div>
</div>
