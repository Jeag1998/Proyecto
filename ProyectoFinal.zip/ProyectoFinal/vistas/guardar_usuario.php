<?php
session_start();
require_once '../controlador/usuarioController.php';

$controlador = new UsuarioController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $resultado = $controlador->crearUsuario($_POST, $_FILES);

    if ($resultado === true) {
        header("Location: dashboard.php");
        exit;
    } else {
        $_SESSION['mensaje_error'] = $resultado;
        header("Location: nuevo_usuario.php");
        exit;
    }
}
