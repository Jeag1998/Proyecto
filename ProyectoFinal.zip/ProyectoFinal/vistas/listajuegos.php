<?php
session_start();
require_once '../conexion/conexion.php';
include 'includes/layout.php';

// Verifica si el usuario está logueado
if (!isset($_SESSION['cod_usuario'])) {
    header("Location: ../index.php");
    exit();
}

require_once '../controlador/controladorVideojuego.php';
?>

<html>
<body>
    <div class="container text-light" style="margin-left: 180px; margin-top: 56px;">
        <h2 class="text-info">📄 Lista de Videojuegos</h2>
        <table class="table table-dark table-striped mt-4">
            <thead>
                <tr>
                    <th>Título</th>
                    <th>Plataforma</th>
                    <th>Género</th>
                    <th>Fecha de Lanzamiento</th>
                    <th>Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($juegos as $juego): ?>
                    <tr>
                        <td><?= htmlspecialchars($juego['titulo']) ?></td>
                        <td><?= htmlspecialchars($juego['plataforma']) ?></td>
                        <td><?= htmlspecialchars($juego['genero']) ?></td>
                        <td><?= date('d/m/Y', strtotime($juego['fecha_lanzamiento'])) ?></td>
                        <td>
                            <a href="detalles_juegos.php?id=<?= $juego['id'] ?>" class="btn btn-info btn-sm">Ver detalles</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center mt-4">
                <?php if ($pagina_actual > 1): ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?= $pagina_actual - 1 ?>">Anterior</a>
                    </li>
                <?php endif; ?>

                <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                    <li class="page-item <?= $i == $pagina_actual ? 'active' : '' ?>">
                        <a class="page-link" href="?pagina=<?= $i ?>"><?= $i ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($pagina_actual < $total_paginas): ?>
                    <li class="page-item">
                        <a class="page-link" href="?pagina=<?= $pagina_actual + 1 ?>">Siguiente</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</body>
</html>