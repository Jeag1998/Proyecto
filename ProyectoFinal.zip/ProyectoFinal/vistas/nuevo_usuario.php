<?php
$titulo = "Crear Nuevo Usuario";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($titulo) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #f0f2f5;
            font-family: 'Segoe UI', sans-serif;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
        }

        .volver {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #007bff;
            color: white;
            padding: 8px 16px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 14px;
        }

        .volver:hover {
            background-color: #0056b3;
        }

        .form-container {
            background-color: #ffffff;
            padding: 40px 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 420px;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }

        .form-label {
            font-weight: 500;
            color: #333;
        }

        .btn-primary {
            width: 100%;
            padding: 12px;
        }

        .form-control {
            margin-bottom: 16px;
        }
    </style>
</head>
<body>

<a href="../index.php" class="volver">← Volver</a>

<div class="form-container">
    <h2>Nuevo Usuario</h2>
    <form action="guardarusuario.php" method="POST" enctype="multipart/form-data">
        <div>
            <label for="nametag" class="form-label">Nametag *</label>
            <input type="text" name="nametag" id="nametag" class="form-control" required>
        </div>

        <div>
            <label for="contraseña" class="form-label">Contraseña *</label>
            <input type="password" name="contraseña" id="contraseña" class="form-control" required>
        </div>

        <div>
            <label for="nombre" class="form-label">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control">
        </div>

        <div>
            <label for="email" class="form-label">Correo electrónico</label>
            <input type="email" name="email" id="email" class="form-control">
        </div>

        <div>
            <label for="fecha_nacimiento" class="form-label">Fecha de nacimiento</label>
            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" class="form-control">
        </div>

        <div>
            <label for="imagen" class="form-label">Imagen de perfil</label>
            <input type="file" name="imagen" id="imagen" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Crear Usuario</button>
    </form>
</div>

</body>
</html>
