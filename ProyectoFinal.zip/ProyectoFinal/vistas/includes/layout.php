<?php
// Asegurar que no hay output antes de posibles redirects
ob_start();

if (!isset($titulo)) {
    $titulo = "BytePlay";
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($titulo ?? "BytePlay") ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@600&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #1a2028;
            color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: 180px;
            background-color: #161b22;
            color: white;
            padding-top: 2rem;
            position: fixed;
            height: 100vh;
            border-right: 1px solid #343a40;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .sidebar h4 {
            text-align: center;
            margin-bottom: 2rem;
            font-weight: bold;
            color: #0dcaf0;
            font-family: 'Orbitron', sans-serif;
            font-size: 1.1rem;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 0.75rem 1rem;
            transition: background-color 0.3s, padding-left 0.3s;
            font-size: 0.95rem;
        }

        .sidebar a:hover {
            background-color: #21262d;
            padding-left: 1.5rem;
        }

        .content {
            margin-left: 180px;
            padding: 3rem;
            width: calc(100% - 180px);
            margin-top: 56px;
            /* para dejar espacio a la navbar */
        }

        .footer {
            background-color: #1c1f23;
            border-top: 1px solid #343a40;
            color: #adb5bd;
            text-align: center;
            padding: 1rem;
        }

        .footer a {
            color: #0dcaf0;
            text-decoration: none;
        }

        .navbar-custom {
            background-color: #161b22;
            border-bottom: 1px solid #343a40;
            padding: 0.5rem 1rem;
            margin-left: 180px;
            width: calc(100% - 180px);
            position: fixed;
            top: 0;
            z-index: 1000;
        }

        .navbar-custom .navbar-brand {
            color: #0dcaf0;
            font-family: 'Orbitron', sans-serif;
        }

        .navbar-custom .nav-link,
        .navbar-custom .dropdown-toggle {
            color: #f8f9fa;
        }

        .navbar-custom .nav-link:hover,
        .navbar-custom .dropdown-toggle:hover {
            color: #0dcaf0;
        }

        .dropdown-menu {
            background-color: #21262d;
        }

        .dropdown-menu a {
            color: white;
        }

        .dropdown-menu a:hover {
            background-color: #343a40;
        }

        .scrollable-games {
            max-height: calc(100vh - 300px);
            /* Ajusta según la altura de header + buscador + imagen */
            overflow-y: auto;
            padding-right: 8px;
        }
    </style>
</head>

<body>

    <div class="sidebar">
        <div>
            <h4><a href="dashboard.php">🎮 BytePlay</a></h4>
            <a href="videojuegos.php">Videojuegos</a>
            <a href="agregarjuego.php">Añadir juego</a>
            <a href="coleccion.php">Coleccion</a>
            <a href="merchand.php">Merchand</a>
            <p>------------------</p>
            <h4>Admin</h4>
            <a href="admin_validar_nuevojuego.php">Validar nuevo juego</a>
            <a href="permisos_usuarios.php">Permisos usuarios</a>
        </div>

        <div class="footer">
            <div>Versión 2.4</div>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-custom">
        <div class="container-fluid">
            <span class="navbar-brand">Panel</span>
            <div class="ms-auto dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    👤 Perfil
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="configuracion.php">⚙️ Configuración</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="logout.php">🔒 Cerrar sesión</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>