<?php
require_once '../conexion/auth.php';
require_once '../controlador/usuarioController.php';
require_once '../helpers/util.php';

$controller = new usuarioController();
$usuario = $controller->obtenerUsuarioActual();

include 'includes/layout.php';

$carpetaUsuarios = '../public/img/usuarios/';
$rutaImagenUsuario = obtenerRutaImagen($usuario['imagen'] ?? '', $carpetaUsuarios);
?>

<div class="content">
    <h2 class="mb-4">Información del Usuario</h2>

    <div class="row">
        <!-- Imagen de perfil -->
        <div class="col-md-4 text-center mb-4">
            <img src="<?= htmlspecialchars($rutaImagenUsuario) ?>" alt="Imagen de perfil" class="img-thumbnail rounded-circle mb-3" style="max-width: 200px; max-height: 200px; object-fit: cover;">
        </div>

        <!-- Campos solo lectura -->
        <div class="col-md-8">
            <div class="mb-3">
                <label class="form-label">Nametag</label>
                <input type="text" class="form-control bg-secondary text-light" value="<?= htmlspecialchars($usuario['nametag'] ?? '') ?>" readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Nombre</label>
                <input type="text" class="form-control bg-secondary text-light" value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>" readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Correo electrónico</label>
                <input type="email" class="form-control bg-secondary text-light" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" readonly>
            </div>

            <div class="mb-3">
                <label class="form-label">Fecha de nacimiento</label>
                <input type="date" class="form-control bg-secondary text-light" value="<?= htmlspecialchars($usuario['fecha_nacimiento'] ?? '') ?>" readonly>
            </div>
        </div>
    </div>
</div>
