<?php
require_once '../conexion/auth.php';
require_once '../controlador/usuarioController.php';
require_once '../helpers/util.php';

$controller = new usuarioController();
$usuario = $controller->obtenerUsuarioActual();

include 'includes/layout.php';

$carpetaUsuarios = '../imagenes/perfil/';
$rutaImagenUsuario = obtenerRutaImagen($usuario['imagen'] ?? '', $carpetaUsuarios);
?>

<div class="content">
    <h2 class="mb-4">Configuración de Usuario</h2>

    <form action="procesar_configuracion.php" method="POST" enctype="multipart/form-data">
        <div class="row">
            <!-- Imagen de perfil -->
            <div class="col-md-4 text-center mb-4">
                <img src="<?= htmlspecialchars($rutaImagenUsuario) ?>" alt="Imagen de perfil" class="img-thumbnail rounded-circle mb-3" style="max-width: 200px; max-height: 200px; object-fit: cover;">
                <div>
                    <label for="imagen" class="form-label">Cambiar imagen</label>
                    <input type="file" class="form-control form-control-sm" name="imagen" id="imagen" accept="image/*">
                </div>
            </div>

            <!-- Campos editables -->
            <div class="col-md-8">
                <div class="mb-3">
                    <label for="nametag" class="form-label">Nametag (no editable)</label>
                    <input type="text" class="form-control bg-secondary text-light" id="nametag" value="<?= htmlspecialchars($usuario['nametag'] ?? '') ?>" disabled>
                </div>

                <div class="mb-3">
                    <label for="nombre" class="form-label">Nombre</label>
                    <input type="text" class="form-control bg-secondary text-light" name="nombre" id="nombre" value="<?= htmlspecialchars($usuario['nombre'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Correo electrónico</label>
                    <input type="email" class="form-control bg-secondary text-light" name="email" id="email" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label for="fecha_nacimiento" class="form-label">Fecha de nacimiento</label>
                    <input type="date" class="form-control bg-secondary text-light" name="fecha_nacimiento" id="fecha_nacimiento" value="<?= htmlspecialchars($usuario['fecha_nacimiento'] ?? '') ?>">
                </div>

                <button type="submit" class="btn btn-primary mt-3">Guardar cambios</button>
            </div>
        </div>
    </form>
</div>
