<?php
require_once '../conexion/auth.php';
require_once '../controlador/articuloController.php';
require_once '../helpers/util.php';

$controller = new ArticuloController();
$articulos = $controller->obtenerTodos();

include 'includes/layout.php';

$rutaImagenesArticulos = '../public/img/articulos/';
?>

<div class="content text-light">
    <!-- Categorías y carrito arriba -->
    <div class="row mb-4">
        <!-- Categorías -->
        <div class="col-md-6">
            <h5 class="mb-3">Categorías</h5>
            <div class="d-flex flex-wrap gap-2">
                <button class="btn btn-outline-light filter-item" data-categoria="todos">Todos</button>
                <button class="btn btn-outline-light filter-item" data-categoria="mandos">Mandos</button>
                <button class="btn btn-outline-light filter-item" data-categoria="teclado">Teclados</button>
                <button class="btn btn-outline-light filter-item" data-categoria="figuras">Figuras</button>
                <button class="btn btn-outline-light filter-item" data-categoria="headset">Auriculares</button>
                <button class="btn btn-outline-light filter-item" data-categoria="accesorios">Accesorios</button>
              </div>
        </div>

        <!-- Carrito -->
        <div class="col-md-6">
            <h5 class="mb-3">🛒 Carrito</h5>
            <ul id="carrito" class="list-group mb-2"></ul>
            <div class="text-end mb-3">
                <strong>Total: 💲<span id="totalCompra">0.00</span></strong>
            </div>
            <button class="btn btn-success w-100" id="btnComprar">💳 Comprar</button>
        </div>
    </div>

    <!-- Artículos -->
    <div class="row" id="productos">
        <?php foreach ($articulos as $art): ?>
            <div class="col-md-3 mb-4 producto" data-categoria="<?= htmlspecialchars($art['tipo']) ?>">
                <div class="card bg-secondary text-white h-100 shadow-sm" onclick="mostrarDetalles(<?= $art['id'] ?>)" style="cursor:pointer;">
                    <img src="<?= $rutaImagenesArticulos . $art['imagen'] ?>" class="card-img-top" alt="<?= htmlspecialchars($art['nombre']) ?>" style="height: 150px; object-fit: cover;">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($art['nombre']) ?></h5>
                        <p class="card-text">💲<?= number_format($art['precio'], 2) ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal Detalles -->
<div class="modal fade" id="modalDetalles" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content bg-dark text-light">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitulo"></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <img id="modalImagen" src="" class="img-fluid mb-3">
        <p id="modalDescripcion"></p>
        <div class="mb-3">
            <label class="form-label">Cantidad:</label>
            <input type="number" id="modalCantidad" class="form-control" value="1" min="1">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-primary" id="btnAgregarCarrito">➕ Añadir al carrito</button>
      </div>
    </div>
  </div>
</div>

<!-- Modal Pago con pestañas -->
<div class="modal fade" id="modalPago" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <form id="formPago" class="modal-content bg-dark text-light">
      <div class="modal-header">
        <h5 class="modal-title">Formulario de Pago</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <ul class="nav nav-tabs nav-tabs-dark" id="tabPago" role="tablist">
          <li class="nav-item" role="presentation">
            <button class="nav-link active" id="datos-personales-tab" data-bs-toggle="tab" data-bs-target="#datos-personales" type="button" role="tab" aria-controls="datos-personales" aria-selected="true">
              Datos Personales
            </button>
          </li>
          <li class="nav-item" role="presentation">
            <button class="nav-link" id="datos-tarjeta-tab" data-bs-toggle="tab" data-bs-target="#datos-tarjeta" type="button" role="tab" aria-controls="datos-tarjeta" aria-selected="false">
              Datos de Pago
            </button>
          </li>
        </ul>
        <div class="tab-content mt-3" id="tabPagoContent">
          <!-- Pestaña Datos Personales -->
          <div class="tab-pane fade show active" id="datos-personales" role="tabpanel" aria-labelledby="datos-personales-tab">
            <div class="mb-3">
              <label for="nombreCompleto" class="form-label">Nombre Completo</label>
              <input type="text" id="nombreCompleto" name="nombreCompleto" class="form-control" required placeholder="Introduce tu nombre completo">
            </div>
            <div class="mb-3">
              <label for="direccion" class="form-label">Dirección</label>
              <input type="text" id="direccion" name="direccion" class="form-control" required placeholder="Introduce tu dirección">
            </div>
          </div>

          <!-- Pestaña Datos de Pago -->
          <div class="tab-pane fade" id="datos-tarjeta" role="tabpanel" aria-labelledby="datos-tarjeta-tab">
            <div class="mb-3">
              <label class="form-label">Método de pago</label>
              <div class="d-flex gap-3">
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="metodoPago" id="visa" value="Visa" required>
                  <label class="form-check-label" for="visa">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/4/41/Visa_Logo.png" alt="Visa" style="height: 25px;">
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="metodoPago" id="mastercard" value="Mastercard" required>
                  <label class="form-check-label" for="mastercard">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/Mastercard-logo.png" alt="Mastercard" style="height: 25px;">
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="metodoPago" id="paypal" value="PayPal" required>
                  <label class="form-check-label" for="paypal">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/b/b5/PayPal.svg" alt="PayPal" style="height: 25px;">
                  </label>
                </div>
              </div>
            </div>

            <div class="mb-3">
              <label for="numeroTarjeta" class="form-label">Número de Tarjeta</label>
              <input type="text" id="numeroTarjeta" name="numeroTarjeta" class="form-control" required placeholder="XXXX XXXX XXXX XXXX" maxlength="19" pattern="\d{4} \d{4} \d{4} \d{4}">
              <small class="form-text text-muted">Formato: 1234 5678 9012 3456</small>
            </div>

            <div class="row">
              <div class="col-6 mb-3">
                <label for="fechaExpiracion" class="form-label">Fecha de Expiración</label>
                <input type="month" id="fechaExpiracion" name="fechaExpiracion" class="form-control" required min="<?= date('Y-m') ?>">
              </div>
              <div class="col-6 mb-3">
                <label for="cvv" class="form-label">CVV</label>
                <input type="password" id="cvv" name="cvv" class="form-control" required maxlength="3" pattern="\d{3}" placeholder="123">
              </div>
            </div>
          </div>
        </div>

        <div class="mt-3 text-end">
          <strong>Total a pagar: 💲<span id="totalPago">0.00</span></strong>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-success">Confirmar Pago</button>
      </div>
    </form>
  </div>
</div>

<script>
const articulos = <?= json_encode($articulos) ?>;
let carrito = [];
let productoActual = null;

function mostrarDetalles(id) {
    productoActual = articulos.find(p => p.id == id);
    document.getElementById('modalTitulo').innerText = productoActual.nombre;
    document.getElementById('modalDescripcion').innerText = `Tipo: ${productoActual.tipo}`;
    document.getElementById('modalImagen').src = "<?= $rutaImagenesArticulos ?>" + productoActual.id + ".jpg";
    document.getElementById('modalCantidad').value = 1;
    new bootstrap.Modal(document.getElementById('modalDetalles')).show();
}

document.getElementById('btnAgregarCarrito').addEventListener('click', () => {
    const cantidad = parseInt(document.getElementById('modalCantidad').value);
    if (!cantidad || cantidad <= 0) return;
    const item = { ...productoActual, cantidad };
    carrito.push(item);
    actualizarCarrito();
    bootstrap.Modal.getInstance(document.getElementById('modalDetalles')).hide();
});

function actualizarCarrito() {
    const lista = document.getElementById('carrito');
    lista.innerHTML = '';
    carrito.forEach(item => {
        lista.innerHTML += `<li class="list-group-item bg-dark text-white">${item.cantidad} x ${item.nombre} - 💲${(item.precio * item.cantidad).toFixed(2)}</li>`;
    });
    const total = calcularTotal();
    document.getElementById('totalCompra').innerText = total.toFixed(2);
    document.getElementById('totalPago').innerText = total.toFixed(2);
}

// Filtro de categorías
document.querySelectorAll('.filter-item').forEach(el => {
    el.addEventListener('click', () => {
        const categoria = el.dataset.categoria;
        document.querySelectorAll('.producto').forEach(prod => {
            prod.style.display = (categoria === 'todos' || prod.dataset.categoria === categoria) ? 'block' : 'none';
        });
    });
});

// Abrir modal pago al hacer click en Comprar
document.getElementById('btnComprar').addEventListener('click', () => {
    if (carrito.length === 0) {
        alert('El carrito está vacío. Añade algún artículo antes de comprar.');
        return;
    }
    new bootstrap.Modal(document.getElementById('modalPago')).show();
});

// Manejo del formulario de pago
document.getElementById('formPago').addEventListener('submit', function(e) {
    e.preventDefault();

    const nombreCompleto = document.getElementById('nombreCompleto').value.trim();
    const direccion = document.getElementById('direccion').value.trim();
    const metodoPago = document.querySelector('input[name="metodoPago"]:checked');
    const numeroTarjeta = document.getElementById('numeroTarjeta').value.trim();
    const fechaExpiracion = document.getElementById('fechaExpiracion').value;
    const cvv = document.getElementById('cvv').value.trim();

    if (!nombreCompleto || !direccion) {
        alert('Por favor, completa todos los datos personales.');
        return;
    }
    if (!metodoPago) {
        alert('Selecciona un método de pago.');
        return;
    }
    if (!numeroTarjeta || !fechaExpiracion || !cvv) {
        alert('Completa todos los datos de pago.');
        return;
    }

    // Aquí normalmente se enviaría el formulario al servidor para procesar el pago.
    alert(`Gracias por tu compra, ${nombreCompleto}! Método: ${metodoPago.value}. Total: $${calcularTotal().toFixed(2)}`);

    carrito = [];
    actualizarCarrito();
    bootstrap.Modal.getInstance(document.getElementById('modalPago')).hide();
});

function calcularTotal() {
    return carrito.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);
}
</script>
