<?php
require_once '../conexion/auth.php';
require_once '../controlador/usuarioJuegosController.php';
require_once '../helpers/util.php';

if (!isset($_SESSION['nametag'])) {
    header("Location: ../index.php?error=nametag_missing");
    exit();
}

$controller = new UsuarioJuegoController();
$videojuegos = $controller->obtenerPorNametag($_SESSION['nametag']);

include 'includes/layout.php';

$carpetaVideojuegos = '../imagenes/videojuegos/';
?>

<div class="content">
    <div class="container mt-5 text-white">
        <h2 class="mb-4 text-center">🎮 Tu Colección</h2>

        <?php if (empty($videojuegos)): ?>
            <div class="alert alert-info text-center">
                No hay videojuegos en tu colección.
            </div>
        <?php else: ?>
            <div class="row g-4">
                <?php foreach ($videojuegos as $juego): ?>
                    <div class="col-md-6">
                        <div class="card bg-secondary text-white h-100 shadow">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <img src="<?= obtenerRutaImagen($juego['imagen_url'], $carpetaVideojuegos) ?>"
                                         class="img-fluid rounded-start h-100 object-fit-cover"
                                         alt="<?= htmlspecialchars($juego['titulo']) ?>">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <h5 class="card-title"><?= htmlspecialchars($juego['titulo']) ?></h5>
                                        <p class="mb-1"><strong>Género:</strong> <?= htmlspecialchars($juego['genero']) ?></p>
                                        <p class="mb-1"><strong>Plataforma:</strong> <?= htmlspecialchars($juego['plataforma']) ?></p>
                                        <p class="mb-1"><strong>Desarrollador:</strong> <?= htmlspecialchars($juego['desarrollador']) ?></p>
                                        <p class="mb-1"><strong>Lanzamiento:</strong> <?= date("d/m/Y", strtotime($juego['fecha_lanzamiento'])) ?></p>
                                        <p class="mb-1"><strong>Precio:</strong> $<?= number_format($juego['precio'], 2) ?></p>
                                        <p class="card-text"><small><?= htmlspecialchars(substr($juego['descripcion'], 0, 100)) ?>...</small></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
