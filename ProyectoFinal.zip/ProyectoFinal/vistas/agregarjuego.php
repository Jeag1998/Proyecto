<?php
require_once '../conexion/auth.php';
require_once '../controlador/videojuegoController.php';
include 'includes/layout.php';

$videojuegoController = new VideojuegoController();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_POST['estado'] = ($_SESSION['admin'] == 1) ? 'activo' : 'pendiente';
    $resultado = $videojuegoController->crear($_POST, $_FILES);
}
?>

<div class="content">
    <h2 class="mb-4">➕ Agregar Nuevo Videojuego</h2>
    <form method="POST" enctype="multipart/form-data" class="text-light">
        <div class="mb-3">
            <label class="form-label">Título *</label>
            <input type="text" name="titulo" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Género</label>
            <input type="text" name="genero" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Plataforma</label>
            <input type="text" name="plataforma" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Desarrollador</label>
            <input type="text" name="desarrollador" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Fecha de lanzamiento</label>
            <input type="date" name="fecha_lanzamiento" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Precio*</label>
            <input type="number" step="0.01" name="precio" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" rows="4"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Imagen</label>
            <input type="file" name="imagen" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-success">Guardar 🎮</button>
        <a href="videojuegos.php" class="btn btn-outline-light ms-2">← Volver</a>
    </form>
</div>