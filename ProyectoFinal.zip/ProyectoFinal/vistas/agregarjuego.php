<?php
session_start();
require_once '../conexion/conexion.php';
include 'includes/layout.php';

// Verifica si el usuario está logueado
if (!isset($_SESSION['cod_usuario'])) {
    header("Location: ../index.php");
    exit();
}

$conexion = Conexion::conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tituloJuego = $_POST['titulo'] ?? '';
    $genero = $_POST['genero'] ?? '';
    $plataforma = $_POST['plataforma'] ?? '';
    $desarrollador = $_POST['desarrollador'] ?? '';
    $fecha_lanzamiento = $_POST['fecha_lanzamiento'] ?? null;
    $precio = $_POST['precio'] ?? 0.00;
    $descripcion = $_POST['descripcion'] ?? '';
    $imagen_url = $_POST['imagen_url'] ?? '';

    if ($tituloJuego && $genero && $plataforma) {
        $stmt = $conexion->prepare("INSERT INTO videojuegos (titulo, genero, plataforma, desarrollador, fecha_lanzamiento, precio, descripcion, imagen_url) 
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $tituloJuego, $genero, $plataforma,
            $desarrollador ?: null,
            $fecha_lanzamiento ?: null,
            $precio ?: 0.00,
            $descripcion,
            $imagen_url
        ]);
        echo "<div class='alert alert-success'>✅ Videojuego agregado correctamente.</div>";
    } else {
        echo "<div class='alert alert-danger'>❌ Título, género y plataforma son obligatorios.</div>";
    }
}
?>

<div class="container mt-5 text-light">
    <h2 class="mb-4">➕ Agregar Nuevo Videojuego</h2>
    <form method="POST">
        <div class="mb-3">
            <label class="form-label">Título *</label>
            <input type="text" name="titulo" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Género *</label>
            <input type="text" name="genero" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Plataforma *</label>
            <input type="text" name="plataforma" class="form-control" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Desarrollador</label>
            <input type="text" name="desarrollador" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Fecha de lanzamiento</label>
            <input type="date" name="fecha_lanzamiento" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" rows="4"></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">URL de la imagen</label>
            <input type="text" name="imagen_url" class="form-control" placeholder="img/ejemplo.jpg">
        </div>
        <button type="submit" class="btn btn-success">Guardar 🎮</button>
        <a href="listajuegos.php" class="btn btn-outline-light ms-2">← Volver</a>
    </form>
</div>
