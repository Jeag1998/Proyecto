<?php
require_once '../conexion/auth.php';
require_once '../controlador/usuarioController.php';

$controller = new UsuarioController();
$usuarios = $controller->obtenerUsuariosNoAdmin();

include 'includes/layout.php';
?>

<div class="content"> <!-- ⬅️ Esto evita que se superponga -->
    <div class="container mt-5 text-white">
        <h2 class="mb-4">📋 Lista de Usuarios</h2>

        <?php if (empty($usuarios)): ?>
            <div class="alert alert-info text-center">
                Todos los usuarios son administradores.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-dark table-hover table-bordered align-middle">
                    <thead class="table-light text-dark">
                        <tr>
                            <th>ID</th>
                            <th>Nametag</th>
                            <th>Email</th>
                            <th>Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <td><?= $usuario['cod_usuario'] ?></td>
                                <td><?= htmlspecialchars($usuario['nametag']) ?></td>
                                <td><?= htmlspecialchars($usuario['email']) ?></td>
                                <td>
                                    <a href="asignar_permiso.php?cod_usuario=<?= $usuario['cod_usuario'] ?>" class="btn btn-outline-info btn-sm">
                                        Otorgar Permiso Extra
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>