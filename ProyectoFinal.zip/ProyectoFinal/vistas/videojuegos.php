<?php
require_once '../conexion/auth.php';
require_once '../controlador/videojuegoController.php';
require_once '../helpers/util.php';

$controller = new VideojuegoController();
$videojuegos = $controller->obtenerTodos();

include 'includes/layout.php';

$carpetaVideojuegos = '../imagenes/videojuegos/';
?>

<div class="content">
    <!-- Barra de búsqueda + botones -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <input type="text" class="form-control me-3" placeholder="🔍 Buscar videojuegos..." style="flex: 1;">
        <div>
            <a href="coleccion.php" class="btn btn-outline-info">🎮 Tus Juegos</a>
        </div>
    </div>

    <!-- Imagen principal destacada -->
    <div class="mb-5">
        <img src="ruta/a/imagen_destacada.jpg" alt="Imagen destacada" class="img-fluid rounded shadow" style="width: 100%; max-height: 400px; object-fit: cover;">
    </div>

    <!-- Grid de videojuegos -->
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4">
        <?php foreach ($videojuegos as $juego): ?>
            <a href="detallejuego.php?id=<?= $juego['id'] ?>" class="text-decoration-none text-white">
                <div class="card bg-dark text-white h-100 shadow-sm">
                    <img src="<?= obtenerRutaImagen($juego['imagen_url'], $carpetaVideojuegos) ?>" 
                         class="card-img-top" 
                         alt="<?= htmlspecialchars($juego['titulo']) ?>" 
                         style="height: 200px; object-fit: cover;">
                    <div class="card-body d-flex flex-column justify-content-between">
                        <h5 class="card-title"><?= htmlspecialchars($juego['titulo']) ?></h5>
                        <p class="card-text">💲 <?= number_format($juego['precio'], 2) ?></p>
                    </div>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</div>
