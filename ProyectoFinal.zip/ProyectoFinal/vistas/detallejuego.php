<?php
require_once '../conexion/auth.php';
require_once '../controlador/videojuegoController.php';
require_once '../helpers/util.php';

if (!isset($_GET['id'])) {
    header("Location: videojuegos.php");
    exit;
}

$id = intval($_GET['id']);

$controller = new VideojuegoController();
$juego = $controller->obtenerPorId($id);

include 'includes/layout.php';

$carpetaVideojuegos = '../imagenes/videojuegos/';
?>

<div class="content">
    <div class="container mt-5 text-light">
        <?php if (!$juego): ?>
            <div class="alert alert-warning text-center">
                ⚠️ Videojuego no encontrado.
            </div>
            <div class="text-center mt-4">
                <a href="videojuegos.php" class="btn btn-outline-light">← Volver a la lista</a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-5">
                    <img src="<?= obtenerRutaImagen($juego['imagen_url'], $carpetaVideojuegos) ?>" 
                         alt="<?= htmlspecialchars($juego['titulo']) ?>" 
                         class="img-fluid rounded shadow">
                </div>
                <div class="col-md-7">
                    <h2><?= htmlspecialchars($juego['titulo']) ?></h2>
                    <p><strong>Género:</strong> <?= htmlspecialchars($juego['genero']) ?></p>
                    <p><strong>Plataforma:</strong> <?= htmlspecialchars($juego['plataforma']) ?></p>
                    <?php if (!empty($juego['desarrollador'])): ?>
                        <p><strong>Desarrollador:</strong> <?= htmlspecialchars($juego['desarrollador']) ?></p>
                    <?php endif; ?>
                    <?php if (!empty($juego['fecha_lanzamiento'])): ?>
                        <p><strong>Lanzamiento:</strong> <?= date("d/m/Y", strtotime($juego['fecha_lanzamiento'])) ?></p>
                    <?php endif; ?>
                    <p><strong>Precio:</strong> 💲<?= number_format($juego['precio'], 2) ?></p>
                    <?php if (!empty($juego['descripcion'])): ?>
                        <p class="mt-3"><?= nl2br(htmlspecialchars($juego['descripcion'])) ?></p>
                    <?php endif; ?>
                    <a href="videojuegos.php" class="btn btn-outline-light mt-4">← Volver</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
