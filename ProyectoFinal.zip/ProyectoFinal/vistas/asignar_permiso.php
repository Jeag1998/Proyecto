<?php
require_once '../conexion/auth.php';
require_once '../controlador/usuarioController.php';

if ($_SESSION['admin'] != 1) {
    header("Location: ../index.php");
    exit();
}

if (isset($_GET['cod_usuario'])) {
    $codUsuario = $_GET['cod_usuario'];
    $controller = new UsuarioController();
    $resultado = $controller->otorgarPermisoExtra($codUsuario);

    if ($resultado) {
        header("Location: permisos_usuarios.php?exito=1");
    } else {
        header("Location: permisos_usuarios.php?error=1");
    }
} else {
    header("Location: permisos_usuarios.php");
}
