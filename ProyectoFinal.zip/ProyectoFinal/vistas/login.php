<?php
session_start();
require_once '../conexion/conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nametag = $_POST['nametag'];
    $contraseña = $_POST['contraseña'];

    $conexion = Conexion::conectar();

    if ($conexion) {
        $sql = "SELECT * FROM usuarios WHERE nametag = :nametag AND contraseña = :contra";
        $stmt = $conexion->prepare($sql);
        $stmt->bindParam(':nametag', $nametag);
        $stmt->bindParam(':contra', $contraseña);
        $stmt->execute();

        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            // Guardar todos los datos del usuario en la sesión
            $_SESSION['cod_usuario'] = $usuario['cod_usuario'];
            $_SESSION['admin'] = $usuario['admin'];
            $_SESSION['nametag'] = $usuario['nametag'];

            header("Location: dashboard.php");
            exit();
        } else {
            header("Location: ../index.php?error=1");
            exit();
        }
    } else {
        echo "Error en la conexión a la base de datos.";
    }
}
