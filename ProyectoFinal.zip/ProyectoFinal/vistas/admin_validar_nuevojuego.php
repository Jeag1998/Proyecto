<?php
require_once '../conexion/auth.php';
require_once '../controlador/videojuegoController.php';

$controller = new VideojuegoController();
$pendientes = $controller->obtenerPendientes();

// Posición actual
if (!isset($_SESSION['posicion_juego'])) {
    $_SESSION['posicion_juego'] = 0;
}

// Navegación
if (isset($_GET['siguiente'])) {
    $_SESSION['posicion_juego']++;
} elseif (isset($_GET['anterior'])) {
    $_SESSION['posicion_juego']--;
}

// Límite seguro
$_SESSION['posicion_juego'] = max(0, min($_SESSION['posicion_juego'], count($pendientes) - 1));

// Juego actual
$juego = $pendientes[$_SESSION['posicion_juego']] ?? null;

include 'includes/layout.php';
?>

<div class="container d-flex justify-content-center align-items-center vh-100">
    <?php if ($juego): ?>
    <div class="bg-dark text-white p-4 rounded shadow-lg position-relative" style="max-width: 800px; width: 100%;">
        <!-- Flechas -->
        <?php if ($_SESSION['posicion_juego'] > 0): ?>
            <a href="?anterior=1" class="position-absolute top-50 start-0 translate-middle-y text-light fs-2 px-3">&#8592;</a>
        <?php endif; ?>
        <?php if ($_SESSION['posicion_juego'] < count($pendientes) - 1): ?>
            <a href="?siguiente=1" class="position-absolute top-50 end-0 translate-middle-y text-light fs-2 px-3">&#8594;</a>
        <?php endif; ?>

        <!-- Contenido del juego -->
        <div class="text-center">
            <h2 class="mb-3"><?= htmlspecialchars($juego['titulo']) ?></h2>
            <img src="<?= htmlspecialchars($juego['imagen_url']) ?>" alt="<?= $juego['titulo'] ?>" class="img-fluid rounded mb-4 shadow" style="max-height: 300px; object-fit: cover;">

            <p><strong>Género:</strong> <?= htmlspecialchars($juego['genero']) ?></p>
            <p><strong>Plataforma:</strong> <?= htmlspecialchars($juego['plataforma']) ?></p>
            <?php if (!empty($juego['desarrollador'])): ?>
                <p><strong>Desarrollador:</strong> <?= htmlspecialchars($juego['desarrollador']) ?></p>
            <?php endif; ?>
            <?php if (!empty($juego['fecha_lanzamiento'])): ?>
                <p><strong>Lanzamiento:</strong> <?= date("d/m/Y", strtotime($juego['fecha_lanzamiento'])) ?></p>
            <?php endif; ?>
            <p><strong>Precio:</strong> 💲<?= number_format($juego['precio'], 2) ?></p>
            <?php if (!empty($juego['descripcion'])): ?>
                <p class="mt-3"><?= nl2br(htmlspecialchars($juego['descripcion'])) ?></p>
            <?php endif; ?>
        </div>

        <!-- Botones -->
        <form method="POST" class="d-flex justify-content-center mt-4 gap-3">
            <input type="hidden" name="id" value="<?= $juego['id'] ?>">
            <button name="accion" value="aceptar" class="btn btn-success px-4">✅ Aceptar</button>
            <button name="accion" value="rechazar" class="btn btn-danger px-4">❌ Rechazar</button>
        </form>
    </div>
    <?php else: ?>
        <div class="text-center text-white">
            <h3>No hay videojuegos pendientes de validación.</h3>
        </div>
    <?php endif; ?>
</div>

<?php
// Procesar acción
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $idJuego = $_POST['id'];
    $accion = $_POST['accion'];

    if ($accion === 'aceptar') {
        $controller->actualizarEstado($idJuego, 'aceptado');
    } elseif ($accion === 'rechazar') {
        $controller->actualizarEstado($idJuego, 'cancelado');
    }

    // Reiniciar para cargar el siguiente
    $_SESSION['posicion_juego'] = 0;
    header("Location: admin_validar_nuevojuego.php");
    exit;
}
?>
