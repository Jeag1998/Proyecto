<?php
require_once '../conexion/conexion.php';

class Publicidad {

    private $conexion;

    public function __construct() {
        $this->conexion = Conexion::conectar();
    }

    // Obtener todos los registros
    public function obtenerTodos() {
        $sql = "SELECT * FROM publicidad";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener por ID
    public function obtenerPorId($id) {
        $sql = "SELECT * FROM publicidad WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Buscar por palabra clave en la descripción
    public function buscarPorDescripcion($texto) {
        $sql = "SELECT * FROM publicidad WHERE descripcion LIKE ?";
        $stmt = $this->conexion->prepare($sql);
        $like = "%" . $texto . "%";
        $stmt->execute([$like]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
