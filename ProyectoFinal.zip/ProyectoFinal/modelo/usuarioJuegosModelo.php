<?php 
require_once '../conexion/conexion.php';

class UsuarioJuego {

    private $conexion;

    public function __construct() {
        $this->conexion = Conexion::conectar();  
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM usuariosJuegos";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorNametag($nametag) {
        $sql = "SELECT * FROM usuariosJuegos WHERE nametag = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$nametag]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
