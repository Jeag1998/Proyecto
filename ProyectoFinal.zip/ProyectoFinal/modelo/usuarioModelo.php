<?php
require_once '../conexion/conexion.php';

class Usuario
{

    private $conexion;

    public function __construct()
    {
        $this->conexion = Conexion::conectar();
    }

    public function obtenerUsuarioPorCodigo($codUsuario)
    {
        $sql = "SELECT * FROM usuarios WHERE cod_usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$codUsuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerUsuariosNoAdmin()
    {
        $sql = "SELECT cod_usuario, nametag, email FROM usuarios WHERE admin = 0";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
