<?php
require_once '../conexion/conexion.php';

class Usuario
{

    private $conexion;

    public function __construct()
    {
        $this->conexion = Conexion::conectar();
    }

    public function obtenerUsuarioPorCodigo($codUsuario)
    {
        $sql = "SELECT * FROM usuarios WHERE cod_usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$codUsuario]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerUsuariosNoAdmin()
    {
        $sql = "SELECT cod_usuario, nametag, email FROM usuarios WHERE admin = 0";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function crearUsuario($datos)
    {
        if ($this->existeNametagOEmail($datos['nametag'], $datos['email'])) {
            return false; // ya existe nametag o email
        }

        $sql = "INSERT INTO usuarios (nametag, contraseña, nombre, email, fecha_nacimiento, imagen)
            VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([
            $datos['nametag'],
            password_hash($datos['contraseña'], PASSWORD_DEFAULT),
            $datos['nombre'] ?: null,
            $datos['email'] ?: null,
            $datos['fecha_nacimiento'] ?: null,
            $datos['imagen']
        ]);
    }

    public function existeNametagOEmail($nametag, $email)
    {
        $sql = "SELECT COUNT(*) FROM usuarios WHERE nametag = ? OR email = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$nametag, $email]);
        return $stmt->fetchColumn() > 0;
    }

    public function otorgarPermisosAdmin($codUsuario)
    {
        $sql = "UPDATE usuarios SET admin = 1 WHERE cod_usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$codUsuario]);
    }
}
