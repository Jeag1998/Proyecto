<?php 
require_once '../conexion/conexion.php';

class Pedido {

    private $conexion;

    public function __construct() {
        $this->conexion = Conexion::conectar();  
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM pedidos";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorUsuario($usuarioId) {
        $sql = "SELECT * FROM pedidos WHERE id_usuario = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$usuarioId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
