<?php
require_once '../conexion/conexion.php';

class Videojuego
{

    private $conexion;

    public function __construct()
    {
        $this->conexion = Conexion::conectar();
    }

    public function obtenerTodos()
    {
        $sql = "SELECT * FROM videojuegos WHERE estado != 'pendiente' AND estado != 'cancelado'";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id)
    {
        $sql = "SELECT * FROM videojuegos WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPendientes()
    {
        $sql = "SELECT * FROM videojuegos WHERE estado = 'pendiente'";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function actualizarEstado($id, $nuevoEstado)
    {
        $sql = "UPDATE videojuegos SET estado = ? WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$nuevoEstado, $id]);
    }
}
