<?php
require_once '../conexion/conexion.php';

class Videojuego
{

    private $conexion;

    public function __construct()
    {
        $this->conexion = Conexion::conectar();
    }

    public function obtenerTodos()
    {
        $sql = "SELECT * FROM videojuegos WHERE estado != 'pendiente' AND estado != 'cancelado'";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerPorId($id)
    {
        $sql = "SELECT * FROM videojuegos WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function obtenerPendientes()
    {
        $sql = "SELECT * FROM videojuegos WHERE estado = 'pendiente'";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function actualizarEstado($id, $nuevoEstado)
    {
        $sql = "UPDATE videojuegos SET estado = ? WHERE id = ?";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([$nuevoEstado, $id]);
    }

    public function buscarPorTitulo($busqueda)
    {
        $sql = "SELECT * FROM videojuegos 
            WHERE estado != 'pendiente' 
              AND estado != 'cancelado' 
              AND titulo LIKE ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute(['%' . $busqueda . '%']);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function crearVideojuego($datos)
    {
        $sql = "INSERT INTO videojuegos (titulo, genero, plataforma, desarrollador, fecha_lanzamiento, precio, descripcion, imagen_url, estado)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->conexion->prepare($sql);
        return $stmt->execute([
            $datos['titulo'],
            $datos['genero'],
            $datos['plataforma'],
            $datos['desarrollador'],
            $datos['fecha_lanzamiento'],
            $datos['precio'],
            $datos['descripcion'],
            $datos['imagen_url'],
            $datos['estado']
        ]);
    }
}
