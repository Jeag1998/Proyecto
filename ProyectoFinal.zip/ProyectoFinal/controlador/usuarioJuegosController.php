<?php
require_once '../modelo/usuarioJuegosModelo.php';

class UsuarioJuegoController {
    private $usuarioJuegoModelo;

    public function __construct() {
        $this->usuarioJuegoModelo = new UsuarioJuego();
    }

    public function obtenerTodos() {
        $usuariosJuegos = $this->usuarioJuegoModelo->obtenerTodos();
        
        return $usuariosJuegos;
    }

    // Método para obtener por nametag, por ejemplo
    public function obtenerPorNametag($nametag) {
        $registros = $this->usuarioJuegoModelo->obtenerPorNametag($nametag);
        
        return $registros;
    }
}
