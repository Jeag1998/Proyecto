<?php
require_once '../modelo/usuarioModelo.php';

class UsuarioController
{
    private $usuarioModelo;

    public function __construct()
    {
        $this->usuarioModelo = new Usuario();
    }

    public function obtenerUsuarioActual()
    {

        $codUsuario = $_SESSION['cod_usuario'];
        $usuario = $this->usuarioModelo->obtenerUsuarioPorCodigo($codUsuario);

        return $usuario;
    }

    public function obtenerUsuariosNoAdmin()
    {
        return $this->usuarioModelo->obtenerUsuariosNoAdmin();
    }

    public function crearUsuario($post, $file)
    {
        $nombreImagen = null;

        if (!empty($file['imagen']['name'])) {
            $carpetaDestino = "../public/img/usuarios/";
            if (!is_dir($carpetaDestino)) {
                mkdir($carpetaDestino, 0777, true);
            }
            $nombreImagen = uniqid() . '_' . basename($file['imagen']['name']);
            move_uploaded_file($file['imagen']['tmp_name'], $carpetaDestino . $nombreImagen);
        }

        $datos = [
            'nametag' => trim($post['nametag'] ?? ''),
            'contraseña' => trim($post['contraseña'] ?? ''),
            'nombre' => trim($post['nombre'] ?? ''),
            'email' => trim($post['email'] ?? ''),
            'fecha_nacimiento' => $post['fecha_nacimiento'] ?? '',
            'imagen' => $nombreImagen
        ];

        if (empty($datos['nametag']) || empty($datos['contraseña'])) {
            return "Faltan campos obligatorios.";
        }

        $creado = $this->usuarioModelo->crearUsuario($datos);

        if (!$creado) {
            return "El nametag o el correo electrónico ya están en uso.";
        }

        return true;
    }

    public function otorgarPermisoExtra($codUsuario)
    {
        return $this->usuarioModelo->otorgarPermisosAdmin($codUsuario);
    }
}
