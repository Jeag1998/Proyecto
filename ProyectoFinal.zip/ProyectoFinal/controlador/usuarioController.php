<?php
require_once '../modelo/usuarioModelo.php';

class UsuarioController {
    private $usuarioModelo;

    public function __construct() {
        $this->usuarioModelo = new Usuario();
    }

    public function obtenerUsuarioActual() {
        
        $codUsuario = $_SESSION['cod_usuario'];
        $usuario = $this->usuarioModelo->obtenerUsuarioPorCodigo($codUsuario);
        
        return $usuario;
    }

    public function obtenerUsuariosNoAdmin() {
        return $this->usuarioModelo->obtenerUsuariosNoAdmin();
    }
}