<?php
require_once '../modelo/articuloModelo.php';

class ArticuloController {
    private $articuloModelo;

    public function __construct() {
        $this->articuloModelo = new Articulo();
    }

    public function obtenerTodos() {
        $articulos = $this->articuloModelo->obtenerTodos();
        
        return $articulos;
    }
}
