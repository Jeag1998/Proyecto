<?php
require_once '../modelo/pedidoModelo.php';

class PedidoController {
    private $pedidoModelo;

    public function __construct() {
        $this->pedidoModelo = new Pedido();
    }

    public function obtenerTodos() {
        $pedidos = $this->pedidoModelo->obtenerTodos();
        
        return $pedidos;
    }

    // Por ejemplo, obtener pedidos por usuario (si tienes un campo usuario)
    public function obtenerPorUsuario($usuarioId) {
        $pedidos = $this->pedidoModelo->obtenerPorUsuario($usuarioId);
        
        return $pedidos;
    }
}
