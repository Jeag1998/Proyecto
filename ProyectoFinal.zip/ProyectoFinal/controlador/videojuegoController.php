<?php
require_once '../modelo/videojuegoModelo.php';

class VideojuegoController
{
    private $videojuegoModelo;

    public function __construct()
    {
        $this->videojuegoModelo = new Videojuego();
    }

    public function obtenerTodos()
    {
        $videojuegos = $this->videojuegoModelo->obtenerTodos();
        
        return $videojuegos;
    }

    public function obtenerPorId($id)
    {
        $videojuego = $this->videojuegoModelo->obtenerPorId($id);
       
        return $videojuego;
    }

    public function obtenerPendientes()
    {
        $videojuegos = $this->videojuegoModelo->obtenerPendientes();
        
        return $videojuegos;
    }

    public function actualizarEstado($id, $estado)
    {
        $resultado = $this->videojuegoModelo->actualizarEstado($id, $estado);
        
        return true;
    }
}
