<?php
require_once '../modelo/videojuegoModelo.php';

class VideojuegoController
{
    private $videojuegoModelo;

    public function __construct()
    {
        $this->videojuegoModelo = new Videojuego();
    }

    public function obtenerTodos()
    {
        $videojuegos = $this->videojuegoModelo->obtenerTodos();

        return $videojuegos;
    }

    public function obtenerPorId($id)
    {
        $videojuego = $this->videojuegoModelo->obtenerPorId($id);

        return $videojuego;
    }

    public function obtenerPendientes()
    {
        $videojuegos = $this->videojuegoModelo->obtenerPendientes();

        return $videojuegos;
    }

    public function actualizarEstado($id, $estado)
    {
        $resultado = $this->videojuegoModelo->actualizarEstado($id, $estado);

        return true;
    }

    public function buscarPorTitulo($busqueda)
    {
        return $this->videojuegoModelo->buscarPorTitulo($busqueda);
    }

    public function crear($post, $file)
    {
        $estado = ($_SESSION['admin'] == 1) ? 'aceptado' : 'pendiente';
        $nombreImagen = null;

        if (!empty($file['imagen']['name'])) {
            $carpetaDestino = __DIR__ . '/../public/img/videojuegos/';
            $carpetaUrl = 'img/videojuegos/';
            if (!is_dir($carpetaDestino)) {
                mkdir($carpetaDestino, 0777, true);
            }

            $nombreImagen = uniqid() . '_' . basename($file['imagen']['name']);
            $rutaCompleta = $carpetaDestino . $nombreImagen;

            if (!move_uploaded_file($file['imagen']['tmp_name'], $rutaCompleta)) {
                error_log("No se pudo mover el archivo a $rutaCompleta");
            }
        }

        $datos = [
            'titulo' => trim($post['titulo']),
            'genero' => trim($post['genero']),
            'plataforma' => trim($post['plataforma']),
            'desarrollador' => trim($post['desarrollador'] ?? ''),
            'fecha_lanzamiento' => $post['fecha_lanzamiento'] ?? null,
            'precio' => $post['precio'] ?? 0.00,
            'descripcion' => $post['descripcion'] ?? '',
            'imagen_url' => $nombreImagen ?? '',
            'estado' => $estado
        ];

        return $this->videojuegoModelo->crearVideojuego($datos);
    }
}
