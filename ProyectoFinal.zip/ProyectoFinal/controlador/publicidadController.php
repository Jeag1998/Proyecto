<?php
require_once '../modelo/publicidadModelo.php';

class PublicidadController {
    private $publicidadModelo;

    public function __construct() {
        $this->publicidadModelo = new Publicidad();
    }

    public function obtenerTodas() {
        return $this->publicidadModelo->obtenerTodos();
    }

    public function obtenerPorId($id) {
        return $this->publicidadModelo->obtenerPorId($id);
    }

    public function buscarPorDescripcion($texto) {
        return $this->publicidadModelo->buscarPorDescripcion($texto);
    }
}
?>
