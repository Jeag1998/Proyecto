<?php
require_once 'conexion/conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #f5f5f5;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            width: 320px;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 24px;
        }

        .login-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            border: none;
            color: white;
            border-radius: 6px;
            font-size: 16px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .login-container button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-top: 12px;
        }
    </style>
</head>
<body>

    <div class="login-container">
        <h2>Iniciar sesión</h2>
        <form action="vistas/login.php" method="post">
            <input type="nametag" name="nametag" placeholder="Usuario" required>
            <input type="password" name="contraseña" placeholder="Contraseña" required>
            <button type="submit">Entrar</button>
        </form>
        <div style="margin-top: 20px;">
            <a href="vistas/nuevo_usuario.php" style="color: #007bff; text-decoration: none;">¿No tienes cuenta? Crea una aquí</a>
        </div>
        <?php if (isset($_GET['error'])): ?>
            <div class="error">Nametag o contraseña incorrectos</div>
        <?php endif; ?>
    </div>
</body>
</html>
