<?php
class Conexion {
    public static function conectar() {
        $host = 'localhost';
        $db = 'jue001';
        $user = 'root';
        $pass = '';

        try {
            $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $conn;
        } catch (PDOException $e) {
            return false;
        }
    }
}
?>