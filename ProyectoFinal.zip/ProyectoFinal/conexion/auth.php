<?php
session_start();
//Verifica la conexion del usuario
if (!isset($_SESSION['cod_usuario'])) {
    header("Location: ../index.php");
    exit();
}
?>